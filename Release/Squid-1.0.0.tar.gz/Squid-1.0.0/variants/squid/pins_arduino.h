/*
  pins_arduino.h - Pin definition functions for Arduino
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2007 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA
*/

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <avr/pgmspace.h>

#define NUM_DIGITAL_PINS            32
#define NUM_ANALOG_INPUTS           8
#define analogInputToDigitalPin(p)  ((p < NUM_ANALOG_INPUTS) ? (p) + 24 : -1)

#if defined(__AVR_ATmega32__)
	#define digitalPinToInterrupt(p)  ((p) == 2 ? 0 : ((p) == 3 ? 1 : NOT_AN_INTERRUPT))	
#elif defined(__AVR_ATmega644P__)
	#define digitalPinHasPWM(p)         ((p) == 4 || (p) == 5 || (p) == 6 || (p) == 7 || (p) == 19 || (p) == 20)
#elif defined(__AVR_ATmega1284P__)
	#define digitalPinHasPWM(p)         ((p) == 4 || (p) == 5 || (p) == 6 || (p) == 7 || (p) == 19 || (p) == 20 || (p) == 22 || (p) == 23)
#endif

static const uint8_t SS   = 20;
static const uint8_t MOSI = 21;
static const uint8_t MISO = 22;
static const uint8_t SCK  = 23;

static const uint8_t SDA = 9;//PC1
static const uint8_t SCL = 8;//PC0

#define LED_BUILTIN 13

static const uint8_t A0 = 24;
static const uint8_t A1 = 25;
static const uint8_t A2 = 26;
static const uint8_t A3 = 27;
static const uint8_t A4 = 28;
static const uint8_t A5 = 29;
static const uint8_t A6 = 30;
static const uint8_t A7 = 31;

#if defined(__AVR_ATmega32__)
	#define digitalPinToInterrupt(p)  ((p) == 2 ? 0 : ((p) == 3 ? 1 : NOT_AN_INTERRUPT))
			//PCINT0 PCINT1 PCINT2
#else
	#define digitalPinToPCICR(p)    (((p) >= 0 && (p) < NUM_DIGITAL_PINS) ? (&PCICR) : ((uint8_t *)0)) 
			// All digitalPin on 644p/1284p has PCICR
	#define digitalPinToPCICRbit(p) (((p) <= 7) ? 3 : (((p) <= 15) ? 2 : (((p) <= 23) ? 1 : 0)))
	#define digitalPinToPCMSK(p)    (((p) <= 7) ? (&PCMSK3) : (((p) <= 15) ? (&PCMSK2) : (((p) <= 23) ? (&PCMSK1) : (&PCMSK0))))
	#define digitalPinToPCMSKbit(p) ((p) % 8)
	#define digitalPinToInterrupt(p)  ((p) == 2 ? 0 : ((p) == 3 ? 1 : ((p) == 18 ? 2 : NOT_AN_INTERRUPT)))
			//PCINT0 PCINT1 PCINT2
#endif

#ifdef ARDUINO_MAIN

// On the Arduino board, digital pins are also used
// for the analog output (software PWM).  Analog input
// pins are a separate set.

// ATMEL ATMEGA32/644/ATMEGA1284 / SANGUINO
//
//                        +---\/---+
//           (D 16) PB0  1|        |40  PA0 (AI 0 / D31)
//           (D 17) PB1  2|        |39  PA1 (AI 1 / D30)
//       INT2(D 18) PB2  3|        |38  PA2 (AI 2 / D29)
//  PWM+     (D 19) PB3  4|        |37  PA3 (AI 3 / D28)
//  PWM+   SS(D 20) PB4  5|        |36  PA4 (AI 4 / D27)
//       MOSI(D 21) PB5  6|        |35  PA5 (AI 5 / D26)
//  PWM* MISO(D 22) PB6  7|        |34  PA6 (AI 6 / D25)
//  PWM*  SCK(D 23) PB7  8|        |33  PA7 (AI 7 / D24)
//                  RST  9|        |32  AREF
//                  VCC 10|        |31  GND
//                  GND 11|        |30  AVCC
//                XTAL2 12|        |29  PC7 (D 15)
//                XTAL1 13|        |28  PC6 (D 14)
//       RX0 (D 0)  PD0 14|        |27  PC5 (D 13) TDI
//       TX0 (D 1)  PD1 15|        |26  PC4 (D 12) TDO
//  INT0 RX1 (D 2)  PD2 16|        |25  PC3 (D 11) TMS
//  INT1 TX1 (D 3)  PD3 17|        |24  PC2 (D 10) TCK
//  PWM      (D 4)  PD4 18|        |23  PC1 (D 9)  SDA
//  PWM      (D 5)  PD5 19|        |22  PC0 (D 8)  SCL
//  PWM+     (D 6)  PD6 20|        |21  PD7 (D 7)  PWM
//                        +--------+
//
//
// (PWM+ indicates the additional PWM pins on the ATmega644.)
// (PWM* indicates the additional PWM pins on the ATmega1284.)

// these arrays map port names (e.g. port B) to the
// appropriate addresses for various functions (e.g. reading
// and writing)
const uint16_t PROGMEM port_to_mode_PGM[] = {
	NOT_A_PORT,
	(uint16_t) &DDRA,
	(uint16_t) &DDRB,
	(uint16_t) &DDRC,
	(uint16_t) &DDRD,
};

const uint16_t PROGMEM port_to_output_PGM[] = {
	NOT_A_PORT,
	(uint16_t) &PORTA,
	(uint16_t) &PORTB,
	(uint16_t) &PORTC,
	(uint16_t) &PORTD,
};

const uint16_t PROGMEM port_to_input_PGM[] = {
	NOT_A_PORT,
	(uint16_t) &PINA,
	(uint16_t) &PINB,
	(uint16_t) &PINC,
	(uint16_t) &PIND,
};

const uint8_t PROGMEM digital_pin_to_port_PGM[] = {
	PD, /* 0 */
	PD,
	PD,
	PD,
	PD,
	PD,
	PD,
	PD,
	PC, /* 8 */
	PC,
	PC,
	PC,
	PC,
	PC,
	PC, 
	PC,
	PB, /* 16 */
	PB,
	PB,
	PB,
	PB,
	PB,
	PB,
	PB,
	PA, /* 24 */
	PA,
	PA,
	PA,
	PA,
	PA,
	PA,
	PA,
};

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] = {
	_BV(0), /* 0, port D */
	_BV(1),
	_BV(2),
	_BV(3),
	_BV(4),
	_BV(5),
	_BV(6),
	_BV(7),
	_BV(0), /* 8, port C */
	_BV(1),
	_BV(2),
	_BV(3),
	_BV(4),
	_BV(5),
	_BV(6),
	_BV(7),
	_BV(0), /* 16, port B */
	_BV(1),
	_BV(2),
	_BV(3),
	_BV(4),
	_BV(5),
	_BV(6),
	_BV(7),
	_BV(0), /* 24, port A */
	_BV(1),
	_BV(2),
	_BV(3),
	_BV(4),
	_BV(5),
	_BV(6),
	_BV(7),
};

const uint8_t PROGMEM digital_pin_to_timer_PGM[] = {
	NOT_ON_TIMER, /* 0 - port D */
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	TIMER1B,
	TIMER1A,
	// on the ATmega644, digital pin 6 has hardware pwm
#if defined(__AVR_ATmega32__)
	NOT_ON_TIMER,
	TIMER2,
#else
	TIMER2B,
	TIMER2A,
#endif

	NOT_ON_TIMER, /* 8 - port C */
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	
	NOT_ON_TIMER, /* 16 - port B */
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	// on the ATmega644, digital pin 20 has hardware pwm
#if defined(__AVR_ATmega32__)
	NOT_ON_TIMER,
	NOT_ON_TIMER,
#else
	TIMER0A,
	TIMER0B,
#endif
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	
	NOT_ON_TIMER, /* 24 - port A */
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
};

#endif

// These serial port names are intended to allow libraries and architecture-neutral
// sketches to automatically default to the correct port name for a particular type
// of use.  For example, a GPS module would normally connect to SERIAL_PORT_HARDWARE_OPEN,
// the first hardware serial port whose RX/TX pins are not dedicated to another use.
//
// SERIAL_PORT_MONITOR        Port which normally prints to the Arduino Serial Monitor
//
// SERIAL_PORT_USBVIRTUAL     Port which is USB virtual serial
//
// SERIAL_PORT_LINUXBRIDGE    Port which connects to a Linux system via Bridge library
//
// SERIAL_PORT_HARDWARE       Hardware serial port, physical RX & TX pins.
//
// SERIAL_PORT_HARDWARE_OPEN  Hardware serial ports which are open for use.  Their RX & TX
//                            pins are NOT connected to anything by default.
#define SERIAL_PORT_MONITOR   Serial
#define SERIAL_PORT_HARDWARE  Serial

#endif
